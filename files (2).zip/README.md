# Virtual SSD Project

기존 서버/클라이언트 코드(Boost.Asio 기반)를 활용해 만든 가상 SSD 시뮬레이터입니다.

## 구조

```
ssd_shell.cpp   ──TCP 12345──▶  ssd_server.cpp  ──파일 I/O──▶  nand.txt
 (Shell/Client)                  (SSD Application)               (가상 낸드)
```

- **Shell** : 사용자가 명령어를 입력하는 클라이언트
- **SSD App** : 명령어를 파싱하고 nand.txt를 읽기/쓰기하는 서버
- **nand.txt** : 100개의 LBA(각 32비트 값)를 저장하는 텍스트 파일

---

## 빌드 방법

### 방법 1: g++ 직접 빌드
```bash
# SSD 서버
g++ -o ssd_server ssd_server.cpp -lboost_system -lpthread

# Shell 클라이언트
g++ -o ssd_shell ssd_shell.cpp -lboost_system -lpthread
```

### 방법 2: CMake
```bash
mkdir build && cd build
cmake ..
make
```

---

## 실행 방법

터미널 2개를 열고:

```bash
# 터미널 1 - SSD 서버 먼저 실행
./ssd_server

# 터미널 2 - Shell 실행
./ssd_shell
```

---

## 명령어 목록 및 예시

| 명령어 | 형식 | 설명 |
|---|---|---|
| `read` | `read <lba>` | 특정 LBA 읽기 |
| `write` | `write <lba> <0xXXXXXXXX>` | 특정 LBA에 쓰기 |
| `erase` | `erase <lba> <size>` | 연속 LBA 지우기 (최대 10) |
| `fullwrite` | `fullwrite <0xXXXXXXXX>` | 전체 LBA에 같은 값 쓰기 |
| `fullread` | `fullread` | 전체 LBA 출력 |
| `help` | `help` | 도움말 |
| `exit` | `exit` | 종료 |

### 실행 예시

```
SSD> write 5 0xABCDEFFF
[WRITE] LBA 5 <- 0xABCDEFFF 완료

SSD> read 5
[READ] LBA 5 = 0xABCDEFFF

SSD> erase 0 3
[ERASE] LBA 0~2 초기화 완료

SSD> fullwrite 0xAAAABBBB
[FULLWRITE] 전체 100 LBA <- 0xAAAABBBB 완료

SSD> fullread
[FULLREAD] 전체 LBA 출력:
  LBA[ 0] = 0xAAAABBBB  LBA[ 1] = 0xAAAABBBB  ...
```

---

## nand.txt 형식

```
0x00000000   ← LBA 0
0x00000000   ← LBA 1
...
0x00000000   ← LBA 99
```

- 100줄 고정, 각 줄은 `0x` + 8자리 16진수
- 최초 실행 시 자동 생성됨

---

## 확장 아이디어 (과제 심화)

- **WriteBuffer (캐시)** : `flush` 명령어로 버퍼→nand 반영
- **결함 블록 관리** : 특정 LBA를 배드 블록으로 마킹
- **다중 클라이언트** : `async_accept`로 동시 Shell 연결
- **스크립트 실행** : `run <script.txt>` 명령어로 배치 처리
